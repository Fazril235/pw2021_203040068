body {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background: url('assets/img/bg.1.jpg');
    background-size: cover;
}
.table-box {
    width: 200px;
    position: absolute;
    top: 50%;
    
}