<?php
/*
Muhammad Fazril
203040068
https://github.com/Fazril235/pw2021_203040068
Pertemuan 1 - 25 Februari 2021
Menggabungkan dua pengulangan
*/
?>
<?php
for($i = 1; $i < 4; $i++){
    for($j = 1; $j < 4; $j++){
        echo "Ini perulangan ke ($i, $j)<br>";
    }
}
?>

