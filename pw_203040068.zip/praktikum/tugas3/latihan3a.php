<?php 
/*
Muhammad Fazril Fuady Hermawan
203040068
https://github.com/Fazril235/pw2021_203040068
Pertemuan 3
Array
Jumat 10.00 - 11.00
*/
?>

<?php 

$kata = [
    "ada",
    "abel",
    "men",
    "pung",
    "nilai"
];
echo "Array $kata[0]lah suatu vari$kata[1] yang dapat $kata[2]am$kata[3] banyak $kata[4]";

?>