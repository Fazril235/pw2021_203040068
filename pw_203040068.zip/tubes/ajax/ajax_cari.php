<?php 
require '../php/functions.php';

$otomotif = cari($_GET["keyword"]);

?>
