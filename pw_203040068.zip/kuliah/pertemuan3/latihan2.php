<?php
/*
Muhammad Fazril
203040068
https://github.com/Fazril235/pw2021_203040068
Pertemuan 3 - 19 Februari 2021
Mempelajari mengenai struktur kendali php
*/
?>
<?php
// Pengkondisian / Percabangan
// if else
// if else if else 
// ternary
// switch

$x = 20;
if( $x < 20 ) {
    echo "benar";
} elseif( $x == 20 ) {
    echo "bingo!";
} else {
    echo "salah";
}

?>