<?php
/*
Muhammad Fazril
203040068
https://github.com/Fazril235/pw2021_203040068
Pertemuan 2 - 12 Februari 2021
Mempelajari mengenai sintaks php
*/
?>

<?php
// Standar Oitput
// echo, print
// print_r
// var_dump

// Penulisan sintaks PHP
// 1. PHP di dalam HTML
// 2. HTML di dalam PHP

// Variabel dan Tipe Data
// Variabel 
// tidak boleh diawali dengan angka, tapi boleh mengandung angka
// $nama = "Fazril";
// echo "Halo, nama saya $nama";

// operator 
// aritmatika
// + - * / %
// $x = 10;
// $y = 20;
// echo $x * $y;

// penggabung string / concatenation / concat
// // . 
// $nama_depan = "Muhammad";
// $nama_belakang = "Fazril";
// echo $nama_depan . " " . $nama_belakang;
 
// Assignment
// =, +=, -=, *=, /=, %=, .=
// $x = 1;
// $x -= 5;
// echo $x;
// $nama = "Muhammad";
// $nama .= " ";
// $nama .= "Fazril";
// echo $nama;

// Prbandingan 
// <, >, <=, >=, ==, !=
// var_dump(1 == "1");

// identitas 
// ===, !==
// var_dump()

// Logika
// &&, ||, ! 
// $x = 30;
// var_dump($x < 20 || $x % 2 == 0);
?>


